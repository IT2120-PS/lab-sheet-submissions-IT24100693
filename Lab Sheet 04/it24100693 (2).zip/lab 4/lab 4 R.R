setwd("C:/Users/it24100693/Desktop/lab 4")

# import the dataset
branch_data <- read.table("Exercise.txt", header = TRUE , sep = "," )

# check variable type
str(branch_data)
boxplot(branch_data$Sales_X1,main = "Boxplot for sale", ylab = "sales")
summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)


find_outliers <- function(x) {
  Q1 <- quantile(x,0.25)
  Q3 <- quantile(x,0.75)
  IQR_value <- IQR(x)
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 + 1.5 * IQR_value
  returns(outliers) 
                  


outliers_advertising <- find_outliers(branch_data$Advertising_X2)
outerliers_advertising
